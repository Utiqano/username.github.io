// Gestion des connexions utilisateurs
function login() {
    const validCredentials = {
        'A.Amin': 'Plastipart$1',
        'H.Sami': 'Plastipart$1',
        'M.Jérémie': 'Plastipart$1',
        'G.walid': 'Plastipart$1',
        'A.yahyaoui': 'Plastipart$1',
        'J.tarek': 'Plastipart$1',
        'H.trabelsi': 'Plastipart$1',
        'K.ahmed': 'Plastipart$1',
        'G.amine': 'Plastipart$1',
        'M.chamsi': 'Plastipart$1',
        'K.Abdelkader': 'Plastipart$1'
    };

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (validCredentials[username] && validCredentials[username] === password) {
        document.getElementById('login-page').classList.add('hidden');
        document.getElementById('audit-links-page').classList.remove('hidden');
        sessionStorage.setItem('loggedIn', true); // Stocke la session de l'utilisateur
    } else {
        document.getElementById('error-message').classList.remove('hidden');
    }
}

// Gestion de la déconnexion
function logout() {
    sessionStorage.removeItem('loggedIn');
    document.getElementById('audit-links-page').classList.add('hidden');
    document.getElementById('login-page').classList.remove('hidden');
}

// Vérification de la session à l'ouverture de la page
window.onload = function() {
    if (sessionStorage.getItem('loggedIn')) {
        document.getElementById('login-page').classList.add('hidden');
        document.getElementById('audit-links-page').classList.remove('hidden');
    } else {
        document.getElementById('login-page').classList.remove('hidden');
        document.getElementById('audit-links-page').classList.add('hidden');
    }
};
